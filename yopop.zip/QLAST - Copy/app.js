const express = require('express');
const mysql = require('mysql2');
const bodyParser = require('body-parser');
const session = require('express-session');
const path = require('path');
const moment = require('moment');

const app = express();
const port = 5550;

// Database connection
const db = mysql.createConnection({
  host: 'localhost',
  user: 'root',
  password: '',
  database: 'isha_db'
});

db.connect((err) => {
  if (err) throw err;
  console.log('Connected to MySQL database');
});

// Middleware
app.use(bodyParser.urlencoded({ extended: false }));
app.use(session({
  secret: 'secret',
  resave: true,
  saveUninitialized: true
}));

app.set('views', path.join(__dirname, 'views'));

// Set view engine
app.use(express.static('public'))
app.set('view engine', 'ejs');
app.use(bodyParser.json());
app.use(bodyParser.urlencoded({ extended: false }));

// Middleware to check authentication
function checkAuthentication(req, res, next) {
  if (req.session.loggedin) {
    next();
  } else {
    res.redirect('/login');
  }
}

// Routes
app.get('/welcome', (req, res) => { // Changed from '/' to '/welcome'
  res.redirect('/login');
});

app.get('/login', (req, res) => {
  res.render('login', { error: req.session.error });
  delete req.session.error;  // Clear the error message after displaying it
});

app.post('/login', (req, res) => {
  const username = req.body.username;
  const password = req.body.password;

  if (username && password) {
    db.query('SELECT * FROM login WHERE username = ? AND password = ?', [username, password], (err, results) => {
      if (err) throw err;

      if (results.length > 0) {
        req.session.loggedin = true;
        req.session.user = results[0];
        res.redirect('/dashboard');
      } else {
        req.session.error = 'Incorrect Username and/or Password!';
        res.redirect('/login');
      }
    });
  } else {
    req.session.error = 'Please enter Username and Password!';
    res.redirect('/login');
  }
});

app.get('/dashboard', checkAuthentication, (req, res) => {
  res.render('dashboard', { user: req.session.user });
});

app.get('/registration_list', checkAuthentication, (req, res) => {
  db.query('SELECT * FROM register', (err, result) => {
    if (err) {
      res.render('registration_list', { users: '' });
    } else {
      result.forEach(user => {
        user.Date = moment(user.Date).format('DD/MM/YYYY');
      });
      res.render('registration_list', { users: result });
    }
  });
});

app.get('/logout', (req, res) => {
  req.session.destroy((err) => {
    if (err) throw err;
    res.redirect('/login');
  });
});

// Add User Route
app.get('/add', checkAuthentication, (req, res) => {
  res.render('register', {
    title: 'CRUD Operation using NodeJS / ExpressJS / MySQL'
  });
});

app.post('/save', (req, res) => {
  let data = {
    Name: req.body.Name,
    Gender: req.body.Gender,
    Phone: req.body.Phone,
    Courses: req.body.Courses,
    City: req.body.City,
    Address: req.body.Address,
    Email: req.body.Email,
    Date: req.body.Date
  };
  let sql = "INSERT INTO register SET ?";
  db.query(sql, data, (err, results) => {
    if (err) throw err;
    res.redirect('/registration_list');
  });
});

// Select Users Route
app.get('/select', checkAuthentication, (req, res) => {
  const sql = "SELECT * FROM register";
  db.query(sql, (err, result) => {
    if (err) {
      res.render('registration_list', { users: '' });
    } else {
      result.forEach(user => {
        user.Date = moment(user.Date).format('DD/MM/YYYY');
      });
      res.render('registration_list', { users: result });
    }
  });
});

// Edit User Route
app.get('/edit/:id', checkAuthentication, (req, res) => {
  const userId = req.params.id;
  const sql = "SELECT * FROM register WHERE id = ?";
  db.query(sql, userId, (err, result) => {
    if (err) throw err;
    res.render('user_edit', { user: result[0] });
  });
});

app.post('/update', checkAuthentication, (req, res) => {
  const userId = req.body.id;
  const updatedData = {
    Name: req.body.Name,
    Gender: req.body.Gender,
    Phone: req.body.Phone,
    Courses: req.body.Courses,
    City: req.body.City,
    Address: req.body.Address,
    Email: req.body.Email,
    Date: req.body.Date
  };
  const sql = "UPDATE register SET ? WHERE id = ?";
  db.query(sql, [updatedData, userId], (err, result) => {
    if (err) throw err;
    res.redirect('/select');
  });
});

// Delete User Route
app.get('/delete/:id', checkAuthentication, (req, res) => {
  const userId = req.params.id;
  const sql = "DELETE FROM register WHERE id = ?";
  db.query(sql, userId, (err, result) => {
    if (err) throw err;
    res.redirect('/select');
  });
});


////////////////////courses/////////////////////////////







app.get('/view-courses', (req, res) => {
  db.query('SELECT * FROM courses', (err, results) => {
      if (err) throw err;
      res.render('view-courses', { courses: results });
  });
});

app.get('/course/:id', (req, res) => {
  const courseId = req.params.id;
  db.query('SELECT * FROM courses WHERE id = ?', [courseId], (err, results) => {
      if (err) throw err;
      if (results.length > 0) {
          res.render('course_detail', { course: results[0] });
      } else {
          res.status(404).send('Course not found');
      }
  });
});

app.get('/add-course', (req, res) => {
  res.render('add-course');
});

app.post('/add-course', (req, res) => {
  const {
      title,
      description,
      price,
      post_date,
      close_date,
      instructor_name,
      rating,
      duration_weeks,
      what_you_learn
  } = req.body;
  const image = req.files.image;
  const instructor_image = req.files.instructor_image;

  const imagePath = path.join(__dirname, 'public', 'images', image.name);
  const instructorImagePath = path.join(__dirname, 'public', 'images', instructor_image.name);

  image.mv(imagePath, (err) => {
      if (err) return res.status(500).send(err);

      instructor_image.mv(instructorImagePath, (err) => {
          if (err) return res.status(500).send(err);

          // Format the dates
          const formattedPostDate = moment(post_date, 'YYYY-MM-DD').format('DD/MM/YYYY');
          const formattedCloseDate = moment(close_date, 'YYYY-MM-DD').format('DD/MM/YYYY');

          const sql = 'INSERT INTO courses (title, description, price, post_date, close_date, image, instructor_name, instructor_image, rating, duration_weeks, what_you_learn) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)';
          const values = [title, description, price, formattedPostDate, formattedCloseDate, image.name, instructor_name, instructor_image.name, rating, duration_weeks, what_you_learn];

          db.query(sql, values, (err, result) => {
              if (err) throw err;
              res.redirect('/view-courses');
          });
      });
  });
});



app.get('/view-courses-readonly', (req, res) => {
  db.query('SELECT * FROM courses', (err, results) => {
      if (err) throw err;
      res.render('view-courses-readonly', { courses: results });
  });
});




app.get('/edit-course/:id', (req, res) => {
  const courseId = req.params.id;
  db.query('SELECT * FROM courses WHERE id = ?', [courseId], (err, results) => {
      if (err) throw err;
      if (results.length > 0) {
          res.render('edit-course', { course: results[0] });
      } else {
          res.status(404).send('Course not found');
      }
  });
});

app.post('/edit-course/:id', (req, res) => {
  const courseId = req.params.id;
  const {
      title,
      description,
      price,
      post_date,
      close_date,
      instructor_name,
      rating,
      duration_weeks,
      what_you_learn
  } = req.body;
  const image = req.files?.image;
  const instructor_image = req.files?.instructor_image;

  let updateFields = {
      title,
      description,
      price,
      post_date,
      close_date,
      instructor_name,
      rating,
      duration_weeks,
      what_you_learn
  };

  const uploadAndSave = (fieldsToUpdate) => {
      let sql = 'UPDATE courses SET ? WHERE id = ?';
      db.query(sql, [fieldsToUpdate, courseId], (err, result) => {
          if (err) throw err;
          res.redirect('/view-courses');
      });
  };

  if (image) {
      const imagePath = path.join(__dirname, 'public', 'images', image.name);
      image.mv(imagePath, (err) => {
          if (err) return res.status(500).send(err);
          updateFields.image = image.name;
          if (instructor_image) {
              const instructorImagePath = path.join(__dirname, 'public', 'images', instructor_image.name);
              instructor_image.mv(instructorImagePath, (err) => {
                  if (err) return res.status(500).send(err);
                  updateFields.instructor_image = instructor_image.name;
                  uploadAndSave(updateFields);
              });
          } else {
              uploadAndSave(updateFields);
          }
      });
  } else {
      if (instructor_image) {
          const instructorImagePath = path.join(__dirname, 'public', 'images', instructor_image.name);
          instructor_image.mv(instructorImagePath, (err) => {
              if (err) return res.status(500).send(err);
              updateFields.instructor_image = instructor_image.name;
              uploadAndSave(updateFields);
          });
      } else {
          uploadAndSave(updateFields);
      }
  }
});

app.post('/delete-course/:id', (req, res) => {
  const courseId = req.params.id;
  db.query('DELETE FROM courses WHERE id = ?', [courseId], (err, result) => {
      if (err) throw err;
      res.redirect('/view-courses');
  });
});






app.listen(port, () => {
  console.log(`Server is running on http://localhost:${port}`);
});
